package HelloWorld;

public class HelloPojo {
	
  private int empId;
  private String empName;
  private String company;
  
public String getCompany() {
	return company;
}
public void setCompany(String company) {
	this.company = company;
}
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}

}
